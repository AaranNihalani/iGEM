MMP-9 20 nM — SWV time-course, peak extraction
================================================

Source data: electrochemical_device/models/11_swv_forward/MMP-9 20nM/#1.xlsx ... #13.xlsx
Column used: "Potential applied (V)" (x-axis) and "WE(1).delta.Current (A)" (forward - backward net current, the SWV signal).

ASSUMPTION (please confirm): the 13 scans are 13 separately-incubated wells
(0, 5, 10, ..., 60 min), scanned back-to-back after incubation stopped, with
file index giving the time order: #1 -> 0 min, #2 -> 5 min, ... #13 -> 60 min.
This is based on the .nox raw-instrument timestamps, which are too irregular
(24s, 38s, then a 26-minute gap, then 10s apart) to be a single live-scanning
session spaced 5 minutes apart - they look like a batch of pre-incubated
samples scanned one after another. If the real protocol was different
(e.g. reverse order, or a continuous live scan), the time axis below needs
re-labelling, but the peak values themselves are unaffected.

Peak extraction: for each scan, peak = the maximum (most anodic) delta-current
value across the full potential sweep, with its potential. This picks out the
MB peak (not the Fc peak further positive) at every timepoint checked.

Files in this folder:
- mmp9_20nM_peak_timecourse.csv   Time (min), peak current (nA), peak potential (mV), fraction of t=0 peak
- peak_current_vs_time.png        Peak current vs incubation time
- all_scans_overlay.png           All 13 voltammograms overlaid, coloured by time
- voltammograms/                  One plot per scan, labelled by file index and assigned time

Headline numbers (20 nM MMP-9, assumed time order):
  t=0 min:  29.60 nA (peak at -166 mV)
  t=30 min: 31.17 nA (peak at -247 mV)
  t=60 min: 25.46 nA (peak at -233 mV)
  -> peak falls to about 86% of its t=0 value by 60 min, i.e. roughly 14%
     apparent signal loss over the hour at 20 nM. The forward model (using the
     unmeasured surface-efficiency estimate of 0.20) predicts a much larger
     drop at 20 nM over 60 min (~55% cut). This single run suggests the real
     surface efficiency may be lower than the 0.20 estimate used in the
     report - exactly the calibration the report's Limitations section flags
     as still needed, so this is a good first data point for that.

Two things worth a second look before trusting this time axis fully:
1. The #1 (t=0) scan's MB peak sits at -166 mV, while every later scan's MB
   peak sits in a tight cluster around -230 to -247 mV. That's a ~70-80 mV
   shift for the first scan only. Could be electrode conditioning on the
   very first scan of the session - worth checking if #1 was a "break-in"
   scan.
2. Peak current rises slightly from t=0 to t=30 (29.6 -> 31.2 nA) before
   falling from t=35 to t=60. A monotonic decay is expected if cutting is
   the only thing happening; the early rise could be baseline/SAM settling
   rather than a real signal increase.

Good news: every scan shows a clean, well-separated second peak around
+290 to +330 mV (visible in all_scans_overlay.png and the individual plots),
consistent with the Fc-hexanethiol reference. This is a real, resolved dual
peak on an actual device scan, not a simulation - worth highlighting.
