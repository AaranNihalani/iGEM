MMP-9 20 nM (folder "MMP-9 20 nM") - Fc and MB peak extraction
==============================================================

Source: electrochemical_device/models/11_swv_forward/MMP-9 20 nM/#n.xlsx
Columns: "Potential applied (V)" (x) and "WE(1).delta.Current (A)" (net SWV current).

Peak windows:
- Fc: +150 to +400 mV (maximum within window)
- MB: -260 to -100 mV (maximum within window)

Time assumption: file index n -> (n-1) x 5 min, i.e. #1 = 0 min ... #13 = 60 min.
Same assumption that was confirmed for the earlier 20 nM folder.

Problems with this dataset:
1. #2.xlsx is an empty file (0 bytes). The only data for that timepoint is
   "#2 (8 mins).nox", a raw binary instrument file that labels this scan as
   8 minutes, not 5. It is excluded here. If the 8-minute label is right, the
   time axis is 0, 8, 10, 15 ... 60, not a uniform 5-min series. Needs checking.
2. Scan #1 (t=0) is different from all other scans: its sweep starts at -200 mV
   (others start at -300 mV), its MB peak sits at -170 mV (others -240 to -250
   mV), and its peaks are roughly double the later values. The same first-scan
   offset appeared in the earlier 20 nM folder. Treat #1 as a likely outlier or
   break-in scan. Without it, the series runs 10-60 min only.
3. Scans 3-13 are noisy, with a ripple of about +/-0.5 nA on the peaks. Fc peak
   position wanders between roughly 290 and 335 mV, with one outlier at 391 mV
   (15 min). Individual points should not be over-read.

Files:
- mmp9_20nM_fc_peaks.csv     per-scan Fc and MB peak height and position
- peaks_vs_time.png          Fc and MB peak height vs time
- all_scans_overlay.png      all readable scans overlaid
- voltammograms/             one plot per scan, Fc and MB peaks marked

Results (nA, as extracted):
  t (min)  Fc peak   MB peak
  0 (#1)   17.22     15.55     <- outlier, see point 2
  10       7.99      8.73
  15       8.78      9.27
  20       8.08      7.77
  25       8.00      7.60
  30       7.84      8.23
  35       8.67      6.81
  40       7.44      6.33
  45       7.17      5.65
  50       6.75      5.80
  55       6.06      4.57
  60       5.96      5.28

Excluding #1, Fc falls from about 8.0 nA at 10 min to about 6.0 nA at 60 min,
roughly 25%. The MB peak falls more, roughly 8.7 to 5.3 nA, but its noise is
comparable to the change.

Not a validated result: single run, no blank (no-MMP-9) control, and Fc is
present in this electrode by design, so the Fc-only signal cannot yet be
separated from fouling or drift.
