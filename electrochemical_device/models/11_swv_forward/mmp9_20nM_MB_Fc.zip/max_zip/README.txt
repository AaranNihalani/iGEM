MMP-9 20 nM: MB and Fc peak heights, cleavable vs non-cleavable

Workbook: mmp9_20nM_MB_Fc_peaks.xlsx (one sheet per folder).
Cleavable = folder 'MMP-9 20 nM' (Oct 3). Non-cleavable = folder 'MMP-9 20nM'.
Time = (file index - 1) x 5 min.
MB window -260 to -100 mV; Fc window +150 to +400 mV; peak = maximum in window.
% of original uses the first valid scan as reference (cell D3 in each sheet);
change D3 and the % columns update only if the reference cell is edited.
Scan #1 in both folders is flagged as an outlier (sweep starts at -200 mV in
the cleavable folder, MB peak shifted about 70 mV vs later scans); it is kept
in the table, highlighted, and excluded from the reference.
Cleavable #2 is an empty .xlsx; its only data is '#2 (8 mins).nox' (labelled 8 min,
not readable here). Shown as missing, not interpolated.
Single runs. No blank (no-MMP-9) control, Fc present by design: not for
kinetic or validation claims.
